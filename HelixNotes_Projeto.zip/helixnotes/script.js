'use strict';
const STORAGE_KEY = 'helixnotes-notes-v1';
const form = document.querySelector('#note-form');
const titleInput = document.querySelector('#note-title');
const contentInput = document.querySelector('#note-content');
const searchInput = document.querySelector('#note-search');
const list = document.querySelector('#notes-list');
const count = document.querySelector('#note-count');
const feedback = document.querySelector('#feedback');

function loadNotes() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(saved) ? saved.filter(note => note && typeof note.id === 'string' && typeof note.title === 'string' && typeof note.content === 'string') : [];
  } catch {
    feedback.textContent = 'Não foi possível ler as notas anteriores.';
    return [];
  }
}
let notes = loadNotes();
function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
    return true;
  } catch {
    feedback.textContent = 'Não foi possível salvar neste navegador. Verifique o armazenamento disponível.';
    return false;
  }
}
function renderNotes() {
  const term = searchInput.value.trim().toLocaleLowerCase('pt-BR');
  const visible = notes.filter(note => `${note.title} ${note.content}`.toLocaleLowerCase('pt-BR').includes(term));
  count.textContent = String(notes.length);
  list.replaceChildren();
  if (!visible.length) {
    const empty = document.createElement('p');
    empty.className = 'empty';
    empty.textContent = term ? 'Nenhuma nota corresponde à busca.' : 'Nenhuma nota ainda. Crie a primeira ao lado!';
    list.append(empty);
    return;
  }
  for (const note of visible) {
    const article = document.createElement('article');
    article.className = 'note';
    const top = document.createElement('div');
    top.className = 'note-top';
    const heading = document.createElement('h4');
    heading.textContent = note.title;
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'delete-button';
    remove.textContent = 'Excluir';
    remove.setAttribute('aria-label', `Excluir nota ${note.title}`);
    remove.addEventListener('click', () => {
      const previous = notes;
      notes = notes.filter(item => item.id !== note.id);
      if (!persist()) { notes = previous; return; }
      feedback.textContent = 'Nota excluída.';
      renderNotes();
    });
    top.append(heading, remove);
    const body = document.createElement('p');
    body.textContent = note.content;
    article.append(top, body);
    list.append(article);
  }
}
form.addEventListener('submit', event => {
  event.preventDefault();
  const title = titleInput.value.trim();
  const content = contentInput.value.trim();
  if (!title || !content) { feedback.textContent = 'Preencha título e conteúdo.'; return; }
  const previous = notes;
  notes = [{ id: `${Date.now()}-${Math.random().toString(36).slice(2)}`, title, content }, ...notes];
  if (!persist()) { notes = previous; return; }
  form.reset();
  feedback.textContent = 'Nota salva com sucesso!';
  renderNotes();
  titleInput.focus();
});
searchInput.addEventListener('input', renderNotes);
renderNotes();
