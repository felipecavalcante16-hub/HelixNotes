# Entrega — HelixNotes

**Aluno:** Felipe Cavalcante Marinho  
**Turma:** GTI — período noturno  
**Projeto:** HelixNotes — Helix Studio

## Requisitos

- [x] R1 — Página HTML, CSS e JS, com layout responsivo implementado
- [x] R2 — Hero, três recursos, demonstração e contato
- [x] R3 — Criar, listar e excluir notas usando `localStorage`; busca adicional
- [x] R4 — Textos próprios, sem lorem ipsum
- [ ] R5 — Console sem erros: sintaxe JS verificada, mas falta inspeção no navegador real
- [ ] R6 — Publicação GitHub + Vercel/Netlify: pendente

## Diário de prompts — registro honesto

**Observação:** o roteiro abaixo representa o desenvolvimento solicitado, mas não deve ser apresentado como transcrição de oito prompts realmente enviados. No histórico disponível há aprovação anterior do plano e pedidos para avançar etapas, mas não há registro completo de todas as interações. Complete o diário oficial com os prompts efetivamente enviados e seus resultados, sem inventar registros.

| Etapa | Objetivo | Situação |
|---|---|---|
| P0 | Planejar e obter aprovação | Aprovação mencionada em conversa anterior |
| P1 | Criar estrutura e hero | Implementado nesta entrega |
| P2 | Criar três cards | Implementado nesta entrega |
| P3 | Criar demonstração persistente | Implementado nesta entrega |
| P4 | Criar contato e revisar textos | Implementado nesta entrega |
| P5 | Ajustar responsividade | CSS com media queries implementado; teste visual pendente |
| P6 | Revisar qualidade | `node --check` e inspeções estáticas executados; revisão no navegador pendente |
| P7 | Criar README | Arquivo criado; commit pendente |

## Prompt efetivamente recebido nesta entrega

O aluno enviou o enunciado completo do desafio **PE//CHALLENGE — Helix Studio**, incluindo requisitos R1–R6, roteiro P0–P7, diário de prompts e instruções de publicação, e solicitou: **“ENTREGA, TUDO Q ESTÁ SOLICITANDO A MATERIA, RESPONDE CORRETAMENTE”**.

**Resultado:** arquivos `index.html`, `styles.css`, `script.js`, `README.md` e este relatório produzidos. Testes estáticos realizados; deploy e teste manual no navegador ainda pendentes.

## Cinco pontos de qualidade revisados

1. **Injeção de HTML:** notas renderizadas com `textContent`, não `innerHTML`.
2. **Persistência:** leitura e escrita de `localStorage` protegidas por `try/catch`.
3. **Formulário:** `required`, `maxlength`, rótulos associados e mensagem `role=status`.
4. **Busca e exclusão:** renderização após cada alteração e botão individual por nota.
5. **Layout:** grades se tornam uma coluna em telas pequenas, com ajuste específico até 375px.

## Como executar

1. Extraia o ZIP.
2. Abra `index.html` no navegador.
3. Crie duas notas e atualize a página: ambas devem permanecer.
4. Pesquise uma palavra e exclua uma nota: atualize novamente e confira.
5. Abra o console do navegador (F12) e confira se há erros.
6. Use a visualização de dispositivos do navegador para testar 375px.

## Como publicar

1. Crie um repositório público no GitHub chamado `helixnotes`.
2. Envie `index.html`, `styles.css`, `script.js` e `README.md` para a raiz do repositório; confirme o commit.
3. Acesse https://vercel.com/new ou https://app.netlify.com/start, entre com GitHub e importe o repositório.
4. Para site estático, deixe o comando de build vazio e a pasta de saída como raiz (`.`), quando necessário.
5. Abra a URL publicada, teste a demo e confira a versão mobile.

## Links para completar antes de entregar ao professor

**GitHub:** PENDENTE — cole a URL real após publicar.  
**Site:** PENDENTE — cole a URL real após deploy.

**Status:** projeto implementado e arquivos preparados; publicação, validação no navegador e diário completo ainda necessários.

## Explicação rápida do código

- `index.html`: estrutura semântica da página e formulário da demo.
- `styles.css`: identidade visual, cartões, grids e responsividade.
- `script.js`: `loadNotes()` lê notas salvas; `persist()` grava no navegador; `renderNotes()` mostra notas filtradas; o evento `submit` cria notas e cada botão Excluir remove uma nota.
- `localStorage` é armazenamento local por navegador/origem; não sincroniza dispositivos e pode ser apagado pelo usuário.
