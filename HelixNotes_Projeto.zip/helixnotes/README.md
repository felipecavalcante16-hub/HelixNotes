# HelixNotes

Site demonstrativo de uma página para um aplicativo de notas voltado a programadores.

Como visualizar: abra `index.html` no navegador ou acesse o link de publicação após realizar o deploy.

Desenvolvido com auxílio de agente de IA, dirigido por Felipe Cavalcante Marinho.
